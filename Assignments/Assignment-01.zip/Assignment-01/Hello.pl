male(ilyas).
male(nisar).
male(razzaq).
male(ishaq).
male(israr).
male(iftikhar).

female(saira).
female(ghazala).
female(akhtari).

father(irshad,ilyas).
father(irshad,nisar).
father(irshad,ishaq).
father(irshad,razzaq).
father(irshad,israr).
father(irshad,iftikhar).




mother(akhtari,ilyas).
mother(akhtari,nisar).
mother(akhtari,ishaq).
mother(akhtari,razzaq).
mother(akhtari,israr).
mother(akhtari,iftikhar).